var searchData=
[
  ['dicecreator',['DiceCreator',['../namespace_inner_drive_studios_1_1_dice_creator.html',1,'InnerDriveStudios']]],
  ['idiesideaware',['IDieSideAware',['../interface_inner_drive_studios_1_1_dice_creator_1_1_i_die_side_aware.html',1,'InnerDriveStudios::DiceCreator']]],
  ['idiesideaware_2ecs',['IDieSideAware.cs',['../_i_die_side_aware_8cs.html',1,'']]],
  ['ids_5flogo',['IDS_LOGO',['../class_inner_drive_studios_1_1_dice_creator_1_1_path_constants.html#a434b3c43410a098299222cb5ed39b6e7',1,'InnerDriveStudios::DiceCreator::PathConstants']]],
  ['ignoreindependentchildevents',['ignoreIndependentChildEvents',['../class_inner_drive_studios_1_1_dice_creator_1_1_die_collection.html#a23c4446897d28a2623632b6849698625',1,'InnerDriveStudios::DiceCreator::DieCollection']]],
  ['index_2etxt',['index.txt',['../index_8txt.html',1,'']]],
  ['innerdrivestudios',['InnerDriveStudios',['../namespace_inner_drive_studios.html',1,'']]],
  ['irollresult',['IRollResult',['../interface_inner_drive_studios_1_1_dice_creator_1_1_i_roll_result.html',1,'InnerDriveStudios::DiceCreator']]],
  ['irollresult_2ecs',['IRollResult.cs',['../_i_roll_result_8cs.html',1,'']]],
  ['isexact',['isExact',['../class_inner_drive_studios_1_1_dice_creator_1_1_die_result.html#a72c78a9ccf55802048b63a715ba4b0cf',1,'InnerDriveStudios.DiceCreator.DieResult.isExact()'],['../interface_inner_drive_studios_1_1_dice_creator_1_1_i_roll_result.html#a72c78a9ccf55802048b63a715ba4b0cf',1,'InnerDriveStudios.DiceCreator.IRollResult.isExact()'],['../class_inner_drive_studios_1_1_dice_creator_1_1_null_result.html#a72c78a9ccf55802048b63a715ba4b0cf',1,'InnerDriveStudios.DiceCreator.NullResult.isExact()'],['../class_inner_drive_studios_1_1_dice_creator_1_1_die_collection_result.html#a72c78a9ccf55802048b63a715ba4b0cf',1,'InnerDriveStudios.DiceCreator.DieCollectionResult.isExact()']]],
  ['isexactmatch',['isExactMatch',['../class_inner_drive_studios_1_1_dice_creator_1_1_die_side_match_info.html#a292086d246a1359c5e96baef2a229807',1,'InnerDriveStudios::DiceCreator::DieSideMatchInfo']]],
  ['isrolling',['isRolling',['../class_inner_drive_studios_1_1_dice_creator_1_1_a_rollable.html#a3346e3056c647d9171bcd277e94d28cd',1,'InnerDriveStudios::DiceCreator::ARollable']]]
];
