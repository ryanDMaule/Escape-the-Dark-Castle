var indexSectionsWithContent =
{
  0: "acdefghiklmnoprstuv",
  1: "adgikmnprs",
  2: "i",
  3: "adgikmnprs",
  4: "acdfghlmorstv",
  5: "acdegiklmnsuv",
  6: "m",
  7: "m",
  8: "cdilnruv",
  9: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Events"
};

