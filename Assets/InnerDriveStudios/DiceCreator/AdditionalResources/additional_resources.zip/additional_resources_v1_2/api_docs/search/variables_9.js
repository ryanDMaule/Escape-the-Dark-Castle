var searchData=
[
  ['normal',['normal',['../class_inner_drive_studios_1_1_dice_creator_1_1_die_area_finder_1_1_die_area.html#ac195757f149b518d7f5436aa9c5c293d',1,'InnerDriveStudios::DiceCreator::DieAreaFinder::DieArea']]],
  ['note',['note',['../class_note.html#a3e5d73e864eecc9d0bb1cb9c8cbb6af3',1,'Note']]]
];
