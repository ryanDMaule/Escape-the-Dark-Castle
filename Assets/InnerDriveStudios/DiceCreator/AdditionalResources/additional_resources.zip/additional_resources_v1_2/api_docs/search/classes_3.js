var searchData=
[
  ['idiesideaware',['IDieSideAware',['../interface_inner_drive_studios_1_1_dice_creator_1_1_i_die_side_aware.html',1,'InnerDriveStudios::DiceCreator']]],
  ['irollresult',['IRollResult',['../interface_inner_drive_studios_1_1_dice_creator_1_1_i_roll_result.html',1,'InnerDriveStudios::DiceCreator']]]
];
