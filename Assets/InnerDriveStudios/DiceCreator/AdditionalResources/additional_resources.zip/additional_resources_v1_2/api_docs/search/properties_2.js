var searchData=
[
  ['isexact',['isExact',['../class_inner_drive_studios_1_1_dice_creator_1_1_die_result.html#a72c78a9ccf55802048b63a715ba4b0cf',1,'InnerDriveStudios.DiceCreator.DieResult.isExact()'],['../interface_inner_drive_studios_1_1_dice_creator_1_1_i_roll_result.html#a72c78a9ccf55802048b63a715ba4b0cf',1,'InnerDriveStudios.DiceCreator.IRollResult.isExact()'],['../class_inner_drive_studios_1_1_dice_creator_1_1_null_result.html#a72c78a9ccf55802048b63a715ba4b0cf',1,'InnerDriveStudios.DiceCreator.NullResult.isExact()'],['../class_inner_drive_studios_1_1_dice_creator_1_1_die_collection_result.html#a72c78a9ccf55802048b63a715ba4b0cf',1,'InnerDriveStudios.DiceCreator.DieCollectionResult.isExact()']]],
  ['isrolling',['isRolling',['../class_inner_drive_studios_1_1_dice_creator_1_1_a_rollable.html#a3346e3056c647d9171bcd277e94d28cd',1,'InnerDriveStudios::DiceCreator::ARollable']]]
];
